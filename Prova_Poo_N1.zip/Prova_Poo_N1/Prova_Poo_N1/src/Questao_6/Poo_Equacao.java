package Questao_6;

public class Poo_Equacao {
    
    public static void main(String[] args){
        
        Sistema app = new Sistema();
        app.executar();
        
    }
    
}
