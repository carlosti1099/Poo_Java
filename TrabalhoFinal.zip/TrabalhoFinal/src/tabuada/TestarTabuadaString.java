package tabuada;

import java.io.IOException;

public class TestarTabuadaString {
    
    public static void main(String[] args) throws IOException {

        TabuadaString tabuada = new TabuadaString();
    }
    
}
