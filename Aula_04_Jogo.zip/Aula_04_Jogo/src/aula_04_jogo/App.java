package aula_04_jogo;

//Professor o vídeo enviado para o Onedrive está com erro
//Portanto estou enviando o que eu consegui fazer.

public class App {
    
    public static void main(String[] args) {
        
        
    }
}
