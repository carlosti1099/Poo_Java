package aula_04_jogo;


import javax.swing.JFrame;
// area em que o jogo é executado
//para ser um jogo é preciso um ambiente grafico
public class Cenario extends JFrame {

    //construtora
    public Cenario() {
        
        // a construtora vai inicializar o cenario
        // ou seja, configurar o ambiente a ser trabalhado
        setSize(800,600); //vai definir o tamanho da janela
        
    }
    
    
}
