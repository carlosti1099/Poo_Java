package testejogovelha;

public class TestarMatriz {
    
    public static void main(String[] args) {

        Tabuleiro t = new Tabuleiro();
    }
}
