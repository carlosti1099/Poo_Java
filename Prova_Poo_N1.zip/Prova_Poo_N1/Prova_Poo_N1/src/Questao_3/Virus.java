package Questao_3;

public class Virus {
    public String nome;
    public String tipo;
    
    public void infectado(){
        
    }
}
