package Questao_3;


public class Cachorro {
    
    //Atributos
    public String nome;
    public String idade;
    public String corDoPelo;
    public int massa;
    public String corOlhos;

    public Cachorro(String nome, String idade, String corDoPelo, int massa, String corOlhos) {
        this.nome = nome;
        this.idade = idade;
        this.corDoPelo = corDoPelo;
        this.massa = massa;
        this.corOlhos = corOlhos;
    }
    
    //Metodos
    public void latir(){
        
    }
    
    public void andar(){
        
    }
    
    public void dormir(){
        
    }
    
    public void comer(){
        
    }
}
